import azure.functions as func
import datetime
import json
import logging
import requests

app = func.FunctionApp()


@app.blob_trigger(arg_name="myblob", path="workflowitem/input/{name}",
                               connection="AzureWebJobsStorage") 
def BlobTriggerFunction(myblob: func.InputStream):
    logging.info(f"Python blob trigger function processed blob"
                f"Name: {myblob.name}"
                f"Blob Size: {myblob.length} bytes")
    
    # Pass parameter to notebook
    parameters = {
            "file" : myblob.name
    }

    databricks_url = "https://adb-1420859118153884.4.azuredatabricks.net"
    databricks_token = "dapi80ebc41f76acd3d821194c788ccc13f4"

    logging.info(f"{databricks_url}/api/2.1/jobs/run-now")

    # Trigger the job
    run_response = requests.post(
            f"{databricks_url}/api/2.1/jobs/run-now",
            headers={"Authorization": f"Bearer {databricks_token}"},
            json={
                    "job_id": "193186874501635",
                    "notebook_params" : parameters
            }
    )

    output = run_response.json()
    logging.info(f"Job run initiated: {output}")
